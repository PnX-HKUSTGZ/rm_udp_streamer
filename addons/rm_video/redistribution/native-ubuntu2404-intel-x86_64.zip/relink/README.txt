FFmpeg n8.1.3 corresponding source and native relinking materials

FFmpeg is LGPL-2.1-or-later, configured without GPL or nonfree components. See ../licenses.
sources contains complete, pinned FFmpeg and nv-codec-headers source archives and checksums.
objects and libraries contain the application/native bridge object code needed to link a modified FFmpeg.
No application EULA in this package restricts modification or reverse engineering to debug LGPL-library modifications.
The application authors retain their other rights; these materials do not change the application source license.

1. Install Python 3.12+ and the compiler version in relink-manifest.json.
2. On the target OS, run: python relink_native.py --output /new/path/librm_video.so
3. To rebuild/modify FFmpeg, use Linux/WSL with make, pkg-config, NASM and GCC:
   python3 rebuild_ffmpeg.py --work /new/work/path
   The fresh build records source/tool identities, logs and installed file digests in build-receipt.json.
   Rebuilt artifacts are unvalidated; they never overwrite the official dependency cache.
   Edit the extracted FFmpeg source, then rerun make and make install in its build directory.
   Manual edits invalidate the original build receipt; record the modified inputs and outputs before validation.
   Original cross tools are MinGW GCC 13.2 win32; native Linux is GCC 13.3.
   VAAPI builds additionally need libva-dev and libdrm-dev (Ubuntu); matching system runtime libraries and GPU drivers are not bundled.
4. Run relink_native.py --ffmpeg-root /path/to/ffmpeg-install --output /new/path/library.
5. Close the receiver, keep a backup, then replace the matching native library in the package.
   Windows uses rm_video.dll beside the executable; Linux uses librm_video.so beside the executable.
   Keep the same x86_64 architecture and FFmpeg ABI; incompatible modifications may require rebuilding application-source/native.
Drivers, compiler tools and operating-system libraries are not included. The original configure command is in ffmpeg/build-manifest.json.
